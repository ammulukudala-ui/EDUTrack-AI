# EDUTrack AI — Student Productivity & Academic Risk Analyzer

A full-stack college project: **Node.js + Express + MongoDB (Mongoose) + HTML/CSS/Bootstrap 5 + jQuery AJAX + Chart.js**.
Students track marks, attendance, study time and tasks; faculty see who may need support; admins manage everything.

> **Honest status:** all code was written and syntax-checked, and the 9 pure-logic unit tests pass.
> It was **not run end-to-end** (no MongoDB / internet in the build environment), so the database-backed tests
> (`auth`, `students`, `analytics`) and the full website still need to be run by you — steps below. If something breaks, see Troubleshooting.

## 1. Problem & solution
Students don't know which subjects need attention; faculty find records scattered. EDUTrack AI centralises marks, attendance, study logs and tasks, then gives **explainable, advisory** risk indicators and **personalised, deterministic** recommendations. It is *rule-based*, not machine learning, and never predicts failure.

## 2. Architecture (simple words)
Browser (HTML + Bootstrap + jQuery) → **AJAX** (JSON) → Express routes → middleware (login check, role check, validation, CSRF) → controllers → Mongoose models → MongoDB → JSON back → jQuery updates tables, cards and Chart.js charts.
The browser never talks to MongoDB directly.

## 3. Setup on Windows + VS Code (step by step)
1. **Node.js**: install the LTS from nodejs.org. Check: `node -v` and `npm -v` in a new terminal.
2. **MongoDB**: install *MongoDB Community Server* (tick "Install as a Service") and optionally *MongoDB Compass*. Check it is running: open Compass → connect to `mongodb://127.0.0.1:27017`.
3. Extract the ZIP, open the folder in VS Code (File → Open Folder). Open **Terminal → New Terminal**.
4. `npm install`
5. Copy `.env.example` to `.env` (`copy .env.example .env`). Set `SESSION_SECRET` to a long random text (`node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`).
6. Demo data (optional): `npm run seed`  (rebuild only demo data: `npm run seed:reset`)
7. Start: `npm run dev` → open **http://localhost:5000**
8. Real admin account (instead of demo): set `ADMIN_*` in `.env` and run `npm run create-admin`.

### Demo logins (fictional, created by `npm run seed`)
| Role | Email | Password |
|---|---|---|
| Admin | admin@edutrack.example | Admin@12345 |
| Faculty | faculty1@edutrack.example (also 2, 3) | Faculty@123 |
| Student | student1@edutrack.example … student8 | Student@123 |

student8 has almost no data → shows the "insufficient data" behaviour. student4/7 show higher advisory scores.
**Never use these on a public server.**

### Check MongoDB changes
Compass → database `edutrack_ai` → collections `users, students, subjects, academicrecords, attendances, studylogs, studytasks, recommendations, riskassessments, auditlogs`. Add/edit/delete a record on the site, then refresh Compass.

## 4. Roles
* **Student**: own dashboard, marks (read-only), attendance (read-only), study logs & tasks (CRUD), risk, recommendations, CSV.
* **Faculty**: only their subjects and students enrolled in them: record marks/attendance, analytics, risk, CSV.
* **Admin**: users, students, subjects (assign faculty/students), all records, stats, audit log.
Enforced in the backend (`services/access.js` + `allowRoles`). Self-registration always creates a *student*.

## 5. Database design
`User` (name, email, passwordHash, role, active) ← `Student` (studentId, user, department, semester, year, subjects[]) ·
`Subject` (code, name, department, semester, credits, faculty→User, active) ·
`AcademicRecord`, `Attendance` (unique student+subject+date), `StudyLog`, `StudyTask` → reference Student + Subject ·
`Recommendation` (unique student+key), `RiskAssessment` (one per student per day), `AuditLog`.
Deleting a student/subject that has linked data **deactivates** it instead.

## 6. Calculations
* Percentage = marks ÷ max marks × 100 (invalid/zero max → ignored).
* Attendance = (Present + Late) ÷ (Present + Late + Absent) × 100. **Excused is not counted.** No sessions → "Insufficient attendance data". Target is configurable (`ATTENDANCE_TARGET`, default 75).
* Overall average = mean of subject averages.

## 7. Risk-scoring algorithm (`config/riskConfig.js`, `services/riskAnalyzer.js`)
Weights: performance 40, attendance 30, trend 20, task completion 10. Each factor gives 0–1 risk × weight.
`score = points earned ÷ max points of factors that had enough data × 100` (0–100).
Categories: **Low ≤ 33, Moderate ≤ 66, High ≤ 100**. Fewer than 3 academic records → **no score** ("insufficient data"). Optional factors (attendance ≥5 sessions, trend ≥5 records, tasks ≥3 due) are skipped and listed as "not included" with a data-completeness %. Every result lists factors, evidence and suggested actions. All numbers editable in one file. Advisory only.

## 8. Recommendation engine (`services/recommendationService.js`)
Rules over real data: weak subjects (<60%), attendance below target, overdue/due-soon tasks, declining recent marks, missing study logs, low study time on the weakest subject. Each has a "Why" and an action; students can complete/dismiss; one per rule per ISO week (no duplicates). Same output shape could later be produced by an ML/LLM model.

## 9. API summary (all JSON, session cookie + `X-CSRF-Token` header on non-GET)
Auth: `GET /api/auth/csrf`, `POST register|login|logout`, `GET me`, `PUT profile|password` ·
CRUD (`POST /`, `GET /`, `GET /:id`, `PUT /:id`, `DELETE /:id`): `/api/students`, `/api/subjects`, `/api/academic-records`, `/api/attendance`, `/api/study-logs`, `/api/tasks` ·
Analytics: `GET /api/analytics/dashboard|performance|attendance|productivity|cohort` ·
Recommendations: `GET /`, `POST /generate`, `PUT /:id`, `DELETE /:id` ·
Risk: `GET /api/risk/my-assessment`, `/students/:id`, `/history/:id` ·
Reports (CSV): `GET /api/reports/:type` (academic, attendance, study, tasks, subject-averages, attendance-summary, study-summary, recommendations, risk) ·
Admin: `/api/admin/stats|users|faculty|audit`.
List endpoints support `page`, `limit` and filters (`subject`, `student`, `from`, `to`, `status`, `q`…).

## 10. jQuery & AJAX
`public/js/main.js` wraps `$.ajax()` (GET/POST/PUT/DELETE) in `EDU.api()` which adds the CSRF token. Every page uses it to load tables (`EDU.crud` builds table + modal form + search/filter/pagination), save forms, refresh charts, generate recommendations and download CSV. Buttons are disabled while a request runs; errors show as toasts/alerts.

## 11. Security implemented
bcrypt hashing, session cookies (httpOnly, sameSite, `secure` in production), session regeneration at login, CSRF token on all writes, login rate limit (10/15 min), Helmet + CSP, express-validator on server, Mongoose validation, role + ownership checks on every route, no password hashes in responses, safe error handler, CSV formula-injection guard, audit log.
**Limitations:** sessions use in-memory store (lost on restart; use `connect-mongo` for production); CSP allows CDN scripts (no SRI hashes); no email verification / password reset; deploy only behind HTTPS (`NODE_ENV=production`, strong `SESSION_SECRET`).

## 12. Tests
`npm run test:unit` — 9 tests, no database (risk, attendance maths, missing data, recommendations, CSV). **Passed in build environment.**
`npm test` — also runs `auth/students/analytics` integration tests against `MONGO_URI_TEST` (a separate `*_test` DB, dropped each run; refuses names without "test"). **Not executed yet — run locally.**

### Manual checklist
Register student → login/logout → admin adds student, subject, assigns faculty → faculty adds marks (try marks > max: rejected) → faculty adds attendance (duplicate date rejected) → student sees them (no edit buttons) → student adds study log + task, marks complete → analytics filters change charts → generate recommendations → risk page → CSV downloads open in Excel → student tries `/admin-dashboard.html` (redirected) and another student's ID in the API (403).

## 13. Troubleshooting
* *MongoDB connection refused*: start the service (`services.msc` → MongoDB Server) and check `MONGO_URI`.
* *Port in use*: change `PORT` in `.env`.
* *`npm` not recognised*: reinstall Node.js, reopen VS Code.
* *`bcrypt` install error*: install Node LTS; or `npm rebuild bcrypt`.
* *403 "Security token"*: refresh the page (session restarted).
* *Charts empty*: no data yet — run `npm run seed`.
* *Records not in Compass*: refresh; confirm database name `edutrack_ai`.

## 14. Future scope
Train/evaluate an ML model on a large representative dataset; email notifications; mobile app; LMS integration; multilingual UI; cloud hosting; multi-college support. (None of these exist yet.)

See `docs/VIVA_AND_PRESENTATION.md` for 40+ viva Q&A and slide content.
