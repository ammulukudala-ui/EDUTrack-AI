# Viva Questions & Answers
1. **Objective?** Centralise marks, attendance, study habits; give advisory risk and recommendations.
2. **Node.js?** JavaScript runtime that runs on the server.
3. **Express.js?** Minimal web framework for routes and middleware.
4. **MongoDB?** NoSQL document database storing JSON-like documents.
5. **Mongoose?** ODM giving schemas, validation and queries for MongoDB.
6. **CRUD?** Create, Read, Update, Delete.
7. **REST API?** URLs + HTTP methods returning JSON for resources.
8. **HTTP methods used?** GET read, POST create, PUT update, DELETE remove.
9. **Status codes?** 200 OK, 201 created, 401 not logged in, 403 forbidden, 404 missing, 409 duplicate, 422 invalid.
10. **jQuery?** JS library simplifying DOM and AJAX.
11. **AJAX?** Requests without reloading the page.
12. **Where is AJAX used?** Login, CRUD forms, charts, filters, recommendations, CSV (`EDU.api`).
13. **Bootstrap?** CSS framework for responsive layout/components.
14. **Why Chart.js?** Draws charts from backend data on canvas.
15. **ObjectId reference?** A field storing another document's `_id` (e.g. record → student).
16. **Why separate collections?** Avoid giant documents; easier queries/updates.
17. **Authentication vs authorization?** Who you are vs what you may do.
18. **Session?** Server remembers the user via a cookie ID.
19. **Why bcrypt?** Slow salted hashing; passwords never stored plain.
20. **Middleware?** Function running before the route handler (auth, validation).
21. **Validation?** Frontend for usability; backend (express-validator + Mongoose) for security.
22. **CSRF?** Attack using your logged-in browser; stopped with a secret token header.
23. **Rate limiting?** Limits login attempts to stop brute force.
24. **Helmet?** Sets secure HTTP headers incl. CSP.
25. **Role-based access?** Permissions by student/faculty/admin enforced in backend.
26. **Why not trust IDs from the browser?** Users can edit requests; server checks ownership.
27. **Risk score?** 0–100 advisory number from weighted rules.
28. **Factors?** Marks, attendance, recent trend, task completion.
29. **Missing data?** No score; shows what's missing — never auto "high risk".
30. **Rule-based vs ML?** Rules are written by us and explainable; ML learns from data.
31. **AI vs ML vs rules?** AI is the broad field; ML is a part that learns; rules are fixed logic.
32. **Is this machine learning?** No, deterministic rules — stated honestly.
33. **Limitations of rules?** Fixed thresholds, can't learn patterns, not validated against outcomes.
34. **Attendance formula?** (Present+Late)/(Present+Late+Absent)×100; Excused excluded.
35. **Percentage formula?** Marks/Max×100.
36. **Recommendation engine?** Rules over real records, each with a "why".
37. **Duplicate prevention?** Unique indexes (attendance, email, student ID, recommendation key).
38. **Safe deletion?** Records with history are deactivated, not deleted.
39. **Frontend↔backend?** jQuery AJAX sends JSON; Express replies JSON; JS updates the page.
40. **How tested?** Node test runner: unit tests plus supertest API tests on a separate DB.
41. **Why `.env`?** Keeps secrets out of code/Git.
42. **Ethical concern?** Scores may mislabel students; so advisory, explained, supportive.
43. **Future work?** Validated ML model, notifications, LMS integration.

# Presentation (slides)
1. **Title** – EDUTrack AI. 2. **Introduction** – academic + productivity monitoring. 3. **Problem** – scattered records, unclear priorities. 4. **Existing system** – spreadsheets/paper/separate portals. 5. **Limitations** – no analysis, delays, no study tracking. 6. **Proposed system** – one web app with analytics and advisory risk. 7. **Objectives** – track, analyse, support. 8. **Features** – marks, attendance, study, tasks, risk, recommendations, CSV. 9. **Stack** – Node, Express, MongoDB, jQuery, Bootstrap, Chart.js. 10. **Architecture** – browser → AJAX → Express → Mongoose → MongoDB. 11. **Database** – collections and references. 12. **Risk analysis** – weights, categories, missing-data rule. 13. **Analytics dashboard** – screenshots (add yours). 14. **Testing** – unit tests pass; add your own integration results. 15. **Advantages**. 16. **Limitations** – rule-based, memory sessions. 17. **Future scope**. 18. **Conclusion**.
